﻿using InventoryManagementData.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryManagementData
{
   public interface IInventoryManage
    {
        IEnumerable<InventoryItem> GetAllStockItem();
       InventoryItem GetInventory(int id);
       void AddNewStock(InventoryItem item);
        void DeleteNewUser(int id);

        void UpdateInventory(InventoryItem item);
    }
}
