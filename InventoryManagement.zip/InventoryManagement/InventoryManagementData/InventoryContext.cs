﻿using InventoryManagementData.Models;
using Microsoft.EntityFrameworkCore;
using System;

namespace InventoryManagementData
{
    public class InventoryContext : DbContext
    {
        public InventoryContext(DbContextOptions options) : base(options) { }

        public DbSet<InventoryItem> InventoryItems { get; set; }
        //public DbSet<Warehouse> Patrons { get; set; }

        


    }
}
