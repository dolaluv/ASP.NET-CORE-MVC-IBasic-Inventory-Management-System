﻿using InventoryManagementData;
using System;
using InventoryManagementData.Models;
using System.Collections.Generic;
using System.Linq;

namespace InventoryManagementServices
{
    public class InventoryServices : IInventoryManage
    {
        private InventoryContext _InventoryContext;

        public InventoryServices(InventoryContext InventoryContext)
        {
            _InventoryContext = InventoryContext;
        }

        public void AddNewStock(InventoryItem item)
        {
            
            _InventoryContext.Add(item);
            _InventoryContext.SaveChanges();
        }

        public void DeleteNewUser(int id)
        {
            var a = GetInventory(id);
            _InventoryContext.InventoryItems.Remove(a);
            _InventoryContext.SaveChanges();
        }

        public IEnumerable<InventoryItem> GetAllStockItem()
        {
            //throw new NotImplementedException();
            return _InventoryContext.InventoryItems;
        }

         
        public InventoryItem GetInventory(int id)
        {
            return GetAllStockItem()
                .FirstOrDefault(userlevel => userlevel.Id == id);

        }

        public void UpdateInventory(InventoryItem item)
        {

            var myItemID = GetInventory(item.Id);

            myItemID = item;

            _InventoryContext.Update(myItemID);
            _InventoryContext.SaveChanges();


        }
    }
}
