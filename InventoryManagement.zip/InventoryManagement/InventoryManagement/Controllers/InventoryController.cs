﻿using InventoryManagement.Models.Inventory;
 
using InventoryManagementData;
using InventoryManagementData.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryManagement.Controllers
{
    public class InventoryController : Controller
    {
        private IInventoryManage _inventory;
        public InventoryController(IInventoryManage inventory)
        {
            _inventory = inventory;

        }

        public IActionResult Index()
        {
            var InventoryModels = _inventory.GetAllStockItem();

            var listingResult = InventoryModels
                .Select(a => new InventoryDetailModel
                {
                    Id = a.Id,
                    ItemName = a.ItemName,
                    ItemDescription = a.ItemDescription,
                    SellingPrice = a.SellingPrice,

                }).ToList();

            var model = new InventoryIndexModel
            {
                MyInventory = listingResult
            };

            return View(model);
        }
        public IActionResult AddInventory()
        {
            
            return View();
        }

        [HttpPost]
        public IActionResult AddInventory(InventoryDetailModel model) //what to happen when check out is clicked
        {

            var myModel = new InventoryItem
            {
                ItemName = model.ItemName,
                ItemDescription = model.ItemDescription,
                SellingPrice = model.SellingPrice,
                CostPrice = model.CostPrice,
                Quantity = model.Quantity


            };

            _inventory.AddNewStock(myModel);
            return RedirectToAction("Index");
        }

        public IActionResult Detail(int id)
        {
            var InventoryDetail = _inventory.GetInventory(id);
            var model = new InventoryDetailModel
            {
                ItemName = InventoryDetail.ItemName,
                ItemDescription = InventoryDetail.ItemDescription,
                SellingPrice = InventoryDetail.SellingPrice,
                CostPrice = InventoryDetail.CostPrice,
                Quantity = InventoryDetail.Quantity,
                // Address = patron.Address
            };
            return View(model);
        }

        public IActionResult DeleteUser(int id)
        {
            _inventory.DeleteNewUser(id);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult EditUser(int id)
        {
            var patron = _inventory.GetInventory(id);
            var model = new InventoryDetailModel
            {
                ItemName = patron.ItemName,
                ItemDescription = patron.ItemDescription,
              //  Address = patron.Address
            };
            return View(model);
        }

        [HttpPost]
        public IActionResult EditUser(int id, InventoryDetailModel model)
        {
          //  var patron = _inventory.GetInventory(id);
           
            var Invento = new InventoryItem
            {
                ItemName = model.ItemName,
                ItemDescription = model.ItemDescription,
                Id = model.Id


            };
            _inventory.UpdateInventory(Invento);
            //_inventory.SaveChanges();

            return RedirectToAction("Index");
        }


    }
}
