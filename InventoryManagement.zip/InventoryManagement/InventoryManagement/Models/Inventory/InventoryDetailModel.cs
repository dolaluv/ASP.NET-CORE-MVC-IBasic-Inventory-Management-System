﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryManagement.Models.Inventory
{
    public class InventoryDetailModel
    {
        public int Id { get; set; }
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public string CostPrice { get; set; }
        public float SellingPrice { get; set; }
        public float Quantity { get; set; }
        public int IsActive { get; set; }
    }
}
