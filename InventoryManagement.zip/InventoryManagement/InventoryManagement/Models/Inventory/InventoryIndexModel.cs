﻿using InventoryManagement.Models.Inventory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryManagement.Models.Inventory
{
    public class InventoryIndexModel
    {
        public IEnumerable<InventoryDetailModel> MyInventory { get; set; }
    }
}
